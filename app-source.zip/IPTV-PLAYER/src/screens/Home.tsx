import React, { useMemo } from 'react'
import { useApp } from '../store'
import { Empty, Icon, Img, Spinner } from '../ui'
import { ChannelRow, Poster, Rail, playLive } from './common'
import type { Item } from '../lib/types'

export function Loading() {
  const app = useApp()
  return (
    <div className="center-fill">
      <Spinner size={44} />
      <div className="muted">{app.loading}</div>
    </div>
  )
}

export function ErrorState() {
  const app = useApp()
  return (
    <Empty
      icon="info"
      title="Couldn’t load your playlist"
      text={app.error}
      action={
        <div className="row gap">
          <button className="btn primary" onClick={() => app.load(app.active, true)} data-autofocus>
            <Icon n="refresh" s={18} /> Try Again
          </button>
          <button className="btn" onClick={() => app.nav.push('settings')}>
            Settings
          </button>
          <button className="btn" onClick={() => app.nav.push('playlists')}>
            Playlists
          </button>
        </div>
      }
    />
  )
}

export function Home() {
  const app = useApp()
  const live = app.visible('live')
  const movies = app.visible('movie')
  const series = app.visible('series')

  const byId = useMemo(() => {
    const m: Record<string, Item> = {}
    ;[...live.items, ...movies.items, ...series.items].forEach((i) => (m[i.kind + ':' + i.id] = i))
    return m
  }, [live, movies, series])

  const hist = Object.values(app.history).sort((a, b) => b.at - a.at)
  const cont = hist.filter((h) => h.kind !== 'live' && h.dur && h.pos && h.pos / h.dur < 0.95)
  const recentLive = hist.filter((h) => h.kind === 'live').map((h) => byId['live:' + h.id]).filter(Boolean).slice(0, 12)
  const favLive = app.favs.live.map((id) => byId['live:' + id]).filter(Boolean)
  const newMovies = useMemo(() => [...movies.items].sort((a, b) => (b.added || 0) - (a.added || 0)).slice(0, 24), [movies])
  const topMovies = useMemo(() => movies.items.filter((m) => (m.rating || 0) >= 7).sort((a, b) => (b.rating || 0) - (a.rating || 0)).slice(0, 24), [movies])
  const newSeries = useMemo(() => [...series.items].sort((a, b) => (b.added || 0) - (a.added || 0)).slice(0, 24), [series])
  const hero = useMemo(() => {
    const pool = (topMovies.length ? topMovies : newMovies).filter((m) => m.logo).slice(0, 8)
    return pool[Math.floor(Math.random() * pool.length)]
  }, [topMovies, newMovies])

  const acc = app.catalog?.account?.user_info
  const resume = (h: (typeof hist)[0]) => {
    if (h.kind === 'movie') app.nav.push('movie', { id: h.id })
    else app.nav.push('series', { id: h.seriesId, resume: h.id })
  }

  return (
    <div className="page">
      {hero ? (
        <div className="hero">
          <Img className="hero-bg" src={hero.logo} alt="" />
          <div className="hero-shade" />
          <div className="hero-content">
            <div className="eyebrow">Featured Movie</div>
            <h1 className="hero-title">{hero.name}</h1>
            <div className="row gap">
              <button className="btn primary xl" onClick={() => app.nav.push('movie', { id: hero.id })} data-autofocus>
                <Icon n="play" fill s={18} /> Watch Now
              </button>
              <button className="btn glass-btn xl" onClick={() => app.toggleFav('movie', hero.id)}>
                <Icon n={app.isFav('movie', hero.id) ? 'check' : 'plus'} s={18} /> My List
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="hero hero-plain">
          <div className="hero-content">
            <div className="eyebrow">{app.active?.name}</div>
            <h1 className="hero-title">Welcome back</h1>
            <div className="row gap">
              <button className="btn primary xl" onClick={() => app.nav.tab('live')} data-autofocus>
                <Icon n="live" s={18} /> Watch Live TV
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="stats">
        <button className="stat" onClick={() => app.nav.tab('live')}>
          <Icon n="live" />
          <b>{live.items.length.toLocaleString()}</b>
          <span>Channels</span>
        </button>
        <button className="stat" onClick={() => app.nav.tab('movies')}>
          <Icon n="movie" />
          <b>{movies.items.length.toLocaleString()}</b>
          <span>Movies</span>
        </button>
        <button className="stat" onClick={() => app.nav.tab('series')}>
          <Icon n="series" />
          <b>{series.items.length.toLocaleString()}</b>
          <span>Series</span>
        </button>
        {acc?.exp_date && (
          <button className="stat" onClick={() => app.nav.push('account')}>
            <Icon n="user" />
            <b>{new Date(Number(acc.exp_date) * 1000).toLocaleDateString()}</b>
            <span>Expires</span>
          </button>
        )}
      </div>

      {cont.length > 0 && (
        <Rail title="Continue Watching">
          {cont.slice(0, 20).map((h) => (
            <button key={h.key} className="wide-card" onClick={() => resume(h)}>
              <div className="wide-img">
                <Img src={h.image} alt={h.name} className="cover" />
                <div className="pbar">
                  <i style={{ width: ((h.pos || 0) / (h.dur || 1)) * 100 + '%' }} />
                </div>
                <span className="play-badge">
                  <Icon n="play" fill s={16} />
                </span>
              </div>
              <div className="poster-name ellip">{h.seriesName || h.name}</div>
              <div className="poster-meta ellip">{h.kind === 'episode' ? `S${h.season} · E${h.episode}` : `${Math.round(((h.dur! - h.pos!) / 60))} min left`}</div>
            </button>
          ))}
        </Rail>
      )}

      {(favLive.length > 0 || recentLive.length > 0) && (
        <Rail title={favLive.length ? 'Favorite Channels' : 'Recently Watched Channels'}>
          {(favLive.length ? favLive : recentLive).map((c, _, arr) => (
            <button key={c.id} className="ch-tile" onClick={() => playLive(app, c, arr)}>
              <Img className="ch-tile-logo" src={c.logo} alt={c.name} />
              <span className="ellip small">{c.name}</span>
            </button>
          ))}
        </Rail>
      )}

      {newMovies.length > 0 && (
        <Rail title="Recently Added Movies" action={<button className="link" onClick={() => app.nav.tab('movies')}>See All</button>}>
          {newMovies.map((m) => (
            <Poster key={m.id} item={m} onClick={() => app.nav.push('movie', { id: m.id })} />
          ))}
        </Rail>
      )}
      {topMovies.length > 0 && (
        <Rail title="Top Rated">
          {topMovies.map((m) => (
            <Poster key={m.id} item={m} onClick={() => app.nav.push('movie', { id: m.id })} />
          ))}
        </Rail>
      )}
      {newSeries.length > 0 && (
        <Rail title="Latest Series" action={<button className="link" onClick={() => app.nav.tab('series')}>See All</button>}>
          {newSeries.map((m) => (
            <Poster key={m.id} item={m} onClick={() => app.nav.push('series', { id: m.id })} />
          ))}
        </Rail>
      )}
      {!live.items.length && !movies.items.length && !series.items.length && (
        <Empty icon="tv" title="This playlist is empty" text="Your provider returned no channels, movies or series." />
      )}
    </div>
  )
}

export { ChannelRow }
