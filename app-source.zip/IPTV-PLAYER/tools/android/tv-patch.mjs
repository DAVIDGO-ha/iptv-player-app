// Runs automatically after `npx cap sync` (package.json "capacitor:sync:after").
// Makes the APK show up on Android TV / Fire TV and uses the app icon.
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const res = path.join(root, 'android/app/src/main/res');
const manifestPath = path.join(root, 'android/app/src/main/AndroidManifest.xml');
if (!fs.existsSync(manifestPath)) { console.log('[tv-patch] no android project, skipped'); process.exit(0); }

let m = fs.readFileSync(manifestPath, 'utf8');
if (!m.includes('LEANBACK_LAUNCHER')) {
  m = m.replace(
    /<category android:name="android.intent.category.LAUNCHER"\s*\/>/,
    '$&\n                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />'
  );
  m = m.replace(
    /<application/,
    '<uses-feature android:name="android.software.leanback" android:required="false" />\n    <uses-feature android:name="android.hardware.touchscreen" android:required="false" />\n\n    <application android:banner="@drawable/banner" android:usesCleartextTraffic="true"'
  );
  fs.writeFileSync(manifestPath, m);
}

fs.mkdirSync(path.join(res, 'drawable'), { recursive: true });
fs.copyFileSync(path.join(root, 'tools/android/banner.png'), path.join(res, 'drawable/banner.png'));

// App icon
fs.rmSync(path.join(res, 'mipmap-anydpi-v26'), { recursive: true, force: true });
for (const d of fs.readdirSync(res).filter((d) => d.startsWith('mipmap-'))) {
  for (const f of ['ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png']) {
    const p = path.join(res, d, f);
    if (fs.existsSync(p)) fs.copyFileSync(path.join(root, 'public/icons/icon-192.png'), p);
  }
}
console.log('[tv-patch] Android TV launcher + banner + icon applied');
